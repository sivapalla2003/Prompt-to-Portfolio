import React, { useState } from 'react';
import { PersonalInfoForm } from './forms/PersonalInfoForm';
import { AboutForm } from './forms/AboutForm';
import { EducationForm } from './forms/EducationForm';
import { WorkExperienceForm } from './forms/WorkExperienceForm';
import { SkillsForm } from './forms/SkillsForm';
import { ProjectsForm } from './forms/ProjectsForm';
import { CertificationsForm } from './forms/CertificationsForm';
import { AchievementsForm } from './forms/AchievementsForm';
import { PublicationsForm } from './forms/PublicationsForm';
import { SummaryForm } from './forms/SummaryForm';
import { 
  User, 
  FileText, 
  GraduationCap, 
  Briefcase, 
  Code, 
  FolderOpen, 
  Award, 
  Trophy, 
  BookOpen, 
  Sparkles 
} from 'lucide-react';

const sections = [
  { id: 'personal', title: 'Personal Info', icon: User, component: PersonalInfoForm },
  { id: 'about', title: 'About', icon: FileText, component: AboutForm },
  { id: 'education', title: 'Education', icon: GraduationCap, component: EducationForm },
  { id: 'work', title: 'Work Experience', icon: Briefcase, component: WorkExperienceForm },
  { id: 'skills', title: 'Skills', icon: Code, component: SkillsForm },
  { id: 'projects', title: 'Projects', icon: FolderOpen, component: ProjectsForm },
  { id: 'certifications', title: 'Certifications', icon: Award, component: CertificationsForm },
  { id: 'achievements', title: 'Achievements', icon: Trophy, component: AchievementsForm },
  { id: 'publications', title: 'Publications', icon: BookOpen, component: PublicationsForm },
  { id: 'summary', title: 'Summary', icon: Sparkles, component: SummaryForm },
];

export const PortfolioBuilder: React.FC = () => {
  const [activeSection, setActiveSection] = useState('personal');

  const ActiveComponent = sections.find(s => s.id === activeSection)?.component || PersonalInfoForm;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
      {/* Sidebar Navigation */}
      <div className="lg:col-span-1">
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 sticky top-24">
          <h2 className="text-xl font-bold text-white mb-6">Portfolio Sections</h2>
          <nav className="space-y-2">
            {sections.map((section) => {
              const Icon = section.icon;
              return (
                <button
                  key={section.id}
                  onClick={() => setActiveSection(section.id)}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-300 transform hover:scale-105 ${
                    activeSection === section.id
                      ? 'bg-gradient-to-r from-green-500 to-teal-500 text-white shadow-lg'
                      : 'text-white/70 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{section.title}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <div className="lg:col-span-3">
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-8">
          <ActiveComponent />
        </div>
      </div>
    </div>
  );
};