import React from 'react';
import { usePortfolio } from '../context/PortfolioContext';
import { useTheme } from '../context/ThemeContext';
import { 
  Mail, 
  Phone, 
  Linkedin, 
  Github, 
  ExternalLink, 
  MapPin,
  Calendar,
  Award,
  Trophy,
  BookOpen,
  User,
  Camera
} from 'lucide-react';

export const PortfolioPreview: React.FC = () => {
  const { data } = usePortfolio();
  const { theme } = useTheme();

  const hasData = (section: any) => {
    if (Array.isArray(section)) return section.length > 0;
    if (typeof section === 'object') return Object.values(section).some(v => v);
    return section && section.trim();
  };

  const themeClasses = {
    dark: 'bg-gradient-to-br from-purple-900 via-indigo-900 to-blue-900',
    light: 'bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50',
    neon: 'bg-gradient-to-br from-black via-gray-900 to-green-900'
  };

  const cardClasses = {
    dark: 'bg-white/10 backdrop-blur-xl border-white/20 glass',
    light: 'bg-white/90 backdrop-blur-xl border-white/30 glass',
    neon: 'bg-green-500/10 backdrop-blur-xl border-green-400/30 glass'
  };

  const textClasses = {
    dark: 'text-white',
    light: 'text-gray-900',
    neon: 'text-green-400'
  };

  const mutedTextClasses = {
    dark: 'text-white/70',
    light: 'text-gray-600',
    neon: 'text-green-300'
  };

  return (
    <div className={`min-h-screen ${themeClasses[theme]} py-8 transition-all duration-500`}>
      <div className="max-w-6xl mx-auto px-4">
        {/* Header Section */}
        {hasData(data.personalInfo) && (
          <div className={`${cardClasses[theme]} rounded-2xl p-8 mb-8 border animate-fadeIn card-3d`}>
            <div className="flex flex-col md:flex-row items-center space-y-6 md:space-y-0 md:space-x-8">
              <div className="relative group">
                <div className="w-32 h-32 rounded-full bg-gradient-to-r from-green-400 to-cyan-400 p-1 animate-pulse-custom">
                  <div className="w-full h-full rounded-full bg-white/10 backdrop-blur-xl overflow-hidden flex items-center justify-center">
                    {data.personalInfo.profilePhoto ? (
                      <img
                        src={data.personalInfo.profilePhoto}
                        alt="Profile"
                        className="w-full h-full object-cover rounded-full"
                      />
                    ) : (
                      <Camera className="w-12 h-12 text-white/50" />
                    )}
                  </div>
                </div>
              </div>
              
              <div className="text-center md:text-left flex-1">
                <h1 className={`text-4xl font-bold ${textClasses[theme]} mb-2`}>
                  {data.personalInfo.name || 'Your Name'}
                </h1>
                <p className={`text-xl ${mutedTextClasses[theme]} mb-4`}>
                  {data.personalInfo.role || 'Your Professional Role'}
                </p>
                
                <div className="flex flex-wrap justify-center md:justify-start gap-4">
                  {data.personalInfo.email && (
                    <a
                      href={`mailto:${data.personalInfo.email}`}
                      className={`flex items-center space-x-2 px-3 py-2 rounded-lg ${cardClasses[theme]} border hover:scale-105 transition-all duration-300 hover:shadow-lg`}
                    >
                      <Mail className="w-4 h-4" />
                      <span className="text-sm">{data.personalInfo.email}</span>
                    </a>
                  )}
                  {data.personalInfo.phone && (
                    <a
                      href={`tel:${data.personalInfo.phone}`}
                      className={`flex items-center space-x-2 px-3 py-2 rounded-lg ${cardClasses[theme]} border hover:scale-105 transition-all duration-300 hover:shadow-lg`}
                    >
                      <Phone className="w-4 h-4" />
                      <span className="text-sm">{data.personalInfo.phone}</span>
                    </a>
                  )}
                  {data.personalInfo.linkedin && (
                    <a
                      href={data.personalInfo.linkedin}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`flex items-center space-x-2 px-3 py-2 rounded-lg ${cardClasses[theme]} border hover:scale-105 transition-all duration-300 hover:shadow-lg`}
                    >
                      <Linkedin className="w-4 h-4" />
                      <span className="text-sm">LinkedIn</span>
                    </a>
                  )}
                  {data.personalInfo.github && (
                    <a
                      href={data.personalInfo.github}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`flex items-center space-x-2 px-3 py-2 rounded-lg ${cardClasses[theme]} border hover:scale-105 transition-all duration-300 hover:shadow-lg`}
                    >
                      <Github className="w-4 h-4" />
                      <span className="text-sm">GitHub</span>
                    </a>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Summary Section */}
        {hasData(data.summary) && (
          <div className={`${cardClasses[theme]} rounded-2xl p-8 mb-8 border animate-fadeIn card-3d`}>
            <h2 className={`text-2xl font-bold ${textClasses[theme]} mb-4`}>Professional Summary</h2>
            <p className={`${mutedTextClasses[theme]} leading-relaxed`}>{data.summary}</p>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-8">
            {/* About Section */}
            {hasData(data.about) && (
              <div className={`${cardClasses[theme]} rounded-2xl p-8 border animate-fadeIn card-3d`}>
                <h2 className={`text-2xl font-bold ${textClasses[theme]} mb-4`}>About Me</h2>
                <p className={`${mutedTextClasses[theme]} leading-relaxed`}>{data.about}</p>
              </div>
            )}

            {/* Work Experience */}
            {hasData(data.workExperience) && (
              <div className={`${cardClasses[theme]} rounded-2xl p-8 border animate-fadeIn card-3d`}>
                <h2 className={`text-2xl font-bold ${textClasses[theme]} mb-6`}>Work Experience</h2>
                <div className="space-y-6">
                  {data.workExperience.map((work) => (
                    <div key={work.id} className="border-l-4 border-purple-500 pl-6">
                      <h3 className={`text-xl font-semibold ${textClasses[theme]}`}>{work.position}</h3>
                      <p className={`${mutedTextClasses[theme]} mb-2`}>{work.company} • {work.duration}</p>
                      <p className={`${mutedTextClasses[theme]} leading-relaxed`}>{work.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Projects */}
            {hasData(data.projects) && (
              <div className={`${cardClasses[theme]} rounded-2xl p-8 border animate-fadeIn card-3d`}>
                <h2 className={`text-2xl font-bold ${textClasses[theme]} mb-6`}>Featured Projects</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {data.projects.map((project) => (
                    <div key={project.id} className={`${cardClasses[theme]} rounded-xl p-6 border hover:scale-105 transition-all duration-300 hover:shadow-xl card-3d`}>
                      {project.image && (
                        <img
                          src={project.image}
                          alt={project.title}
                          className="w-full h-48 object-cover rounded-lg mb-4"
                        />
                      )}
                      <h3 className={`text-lg font-semibold ${textClasses[theme]} mb-2`}>{project.title}</h3>
                      <p className={`${mutedTextClasses[theme]} text-sm mb-4`}>{project.description}</p>
                      <div className="flex flex-wrap gap-2 mb-4">
                        {project.technologies.map((tech) => (
                          <span
                            key={tech}
                            className="px-2 py-1 bg-gradient-to-r from-green-500 to-teal-500 text-white text-xs rounded-full"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                      {project.link && (
                        <a
                          href={project.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className={`inline-flex items-center space-x-1 ${mutedTextClasses[theme]} hover:text-green-500 transition-colors duration-300`}
                        >
                          <ExternalLink className="w-4 h-4" />
                          <span className="text-sm">View Project</span>
                        </a>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right Column */}
          <div className="space-y-8">
            {/* Skills */}
            {hasData(data.skills) && (
              <div className={`${cardClasses[theme]} rounded-2xl p-8 border animate-fadeIn card-3d`}>
                <h2 className={`text-2xl font-bold ${textClasses[theme]} mb-6`}>Skills</h2>
                <div className="space-y-4">
                  {data.skills.map((skill) => (
                    <div key={skill.id}>
                      <div className="flex justify-between mb-1">
                        <span className={`${textClasses[theme]} text-sm font-medium`}>{skill.name}</span>
                        <span className={`${mutedTextClasses[theme]} text-sm`}>{skill.level}%</span>
                      </div>
                      <div className="w-full bg-white/20 rounded-full h-2">
                        <div
                          className="bg-gradient-to-r from-green-400 to-blue-500 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${skill.level}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Education */}
            {hasData(data.education) && (
              <div className={`${cardClasses[theme]} rounded-2xl p-8 border animate-fadeIn card-3d`}>
                <h2 className={`text-2xl font-bold ${textClasses[theme]} mb-6`}>Education</h2>
                <div className="space-y-4">
                  {data.education.map((edu) => (
                    <div key={edu.id}>
                      <h3 className={`${textClasses[theme]} font-semibold`}>{edu.degree}</h3>
                      <p className={`${mutedTextClasses[theme]} text-sm`}>{edu.institution}</p>
                      <p className={`${mutedTextClasses[theme]} text-sm mb-2`}>{edu.year}</p>
                      {edu.description && (
                        <p className={`${mutedTextClasses[theme]} text-sm`}>{edu.description}</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Certifications */}
            {hasData(data.certifications) && (
              <div className={`${cardClasses[theme]} rounded-2xl p-8 border animate-fadeIn card-3d`}>
                <h2 className={`text-2xl font-bold ${textClasses[theme]} mb-6 flex items-center space-x-2`}>
                  <Award className="w-6 h-6" />
                  <span>Certifications</span>
                </h2>
                <div className="space-y-4">
                  {data.certifications.map((cert) => (
                    <div key={cert.id}>
                      <h3 className={`${textClasses[theme]} font-semibold`}>{cert.name}</h3>
                      <p className={`${mutedTextClasses[theme]} text-sm`}>{cert.issuer}</p>
                      <p className={`${mutedTextClasses[theme]} text-sm`}>{cert.date}</p>
                      {cert.link && (
                        <a
                          href={cert.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className={`inline-flex items-center space-x-1 ${mutedTextClasses[theme]} hover:text-green-500 transition-colors duration-300 text-sm`}
                        >
                          <ExternalLink className="w-3 h-3" />
                          <span>Verify</span>
                        </a>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Achievements */}
            {hasData(data.achievements) && (
              <div className={`${cardClasses[theme]} rounded-2xl p-8 border animate-fadeIn card-3d`}>
                <h2 className={`text-2xl font-bold ${textClasses[theme]} mb-6 flex items-center space-x-2`}>
                  <Trophy className="w-6 h-6" />
                  <span>Achievements</span>
                </h2>
                <div className="space-y-4">
                  {data.achievements.map((achievement) => (
                    <div key={achievement.id}>
                      <h3 className={`${textClasses[theme]} font-semibold`}>{achievement.title}</h3>
                      <p className={`${mutedTextClasses[theme]} text-sm mb-1`}>{achievement.date}</p>
                      <p className={`${mutedTextClasses[theme]} text-sm`}>{achievement.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Publications */}
            {hasData(data.publications) && (
              <div className={`${cardClasses[theme]} rounded-2xl p-8 border animate-fadeIn card-3d`}>
                <h2 className={`text-2xl font-bold ${textClasses[theme]} mb-6 flex items-center space-x-2`}>
                  <BookOpen className="w-6 h-6" />
                  <span>Publications</span>
                </h2>
                <div className="space-y-4">
                  {data.publications.map((pub) => (
                    <div key={pub.id}>
                      <h3 className={`${textClasses[theme]} font-semibold`}>{pub.title}</h3>
                      <p className={`${mutedTextClasses[theme]} text-sm`}>{pub.journal}</p>
                      <p className={`${mutedTextClasses[theme]} text-sm`}>{pub.date}</p>
                      {pub.link && (
                        <a
                          href={pub.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className={`inline-flex items-center space-x-1 ${mutedTextClasses[theme]} hover:text-green-500 transition-colors duration-300 text-sm`}
                        >
                          <ExternalLink className="w-3 h-3" />
                          <span>Read More</span>
                        </a>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-12 py-8">
          <p className={`${mutedTextClasses[theme]} text-sm`}>
            Built with SIVAPALLA's Prompt To Portfolio
          </p>
        </div>
      </div>
    </div>
  );
};