import React from 'react';
import { useTheme } from '../context/ThemeContext';
import { Eye, Edit3, Download, Share2, Palette, Sparkles } from 'lucide-react';

interface HeaderProps {
  isPreviewMode: boolean;
  setIsPreviewMode: (mode: boolean) => void;
  setShowExportModal: (show: boolean) => void;
  setShowShareModal: (show: boolean) => void;
}

export const Header: React.FC<HeaderProps> = ({
  isPreviewMode,
  setIsPreviewMode,
  setShowExportModal,
  setShowShareModal,
}) => {
  const { theme, setTheme } = useTheme();

  const themeOptions = [
    { value: 'dark', label: 'Dark', color: 'from-gray-800 to-gray-900' },
    { value: 'light', label: 'Light', color: 'from-white to-gray-100' },
    { value: 'neon', label: 'Neon', color: 'from-green-400 to-cyan-400' },
  ];

  return (
    <header className="bg-black/20 backdrop-blur-xl border-b border-white/10 sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-green-400 to-cyan-400 rounded-xl flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">SIVAPALLA's</h1>
              <p className="text-sm text-green-400">Prompt To Portfolio</p>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            {/* Theme Selector */}
            <div className="flex items-center space-x-2 bg-white/10 rounded-lg p-1">
              {themeOptions.map((option) => (
                <button
                  key={option.value}
                  onClick={() => setTheme(option.value as any)}
                  className={`px-3 py-1 rounded-md text-sm transition-all duration-300 ${
                    theme === option.value
                      ? 'bg-white/20 text-white shadow-lg'
                      : 'text-white/70 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {option.label}
                </button>
              ))}
            </div>

            {/* Mode Toggle */}
            <button
              onClick={() => setIsPreviewMode(!isPreviewMode)}
              className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg hover:from-purple-600 hover:to-pink-600 transition-all duration-300 transform hover:scale-105"
            >
              {isPreviewMode ? <Edit3 className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              <span>{isPreviewMode ? 'Edit' : 'Preview'}</span>
            </button>

            {/* Export Button */}
            <button
              onClick={() => setShowExportModal(true)}
              className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-green-500 to-teal-500 text-white rounded-lg hover:from-green-600 hover:to-teal-600 transition-all duration-300 transform hover:scale-105"
            >
              <Download className="w-4 h-4" />
              <span>Export</span>
            </button>

            {/* Share Button */}
            <button
              onClick={() => setShowShareModal(true)}
              className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white rounded-lg hover:from-blue-600 hover:to-indigo-600 transition-all duration-300 transform hover:scale-105"
            >
              <Share2 className="w-4 h-4" />
              <span>Share</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};