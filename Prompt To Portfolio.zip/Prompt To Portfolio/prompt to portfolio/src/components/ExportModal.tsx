import React, { useState } from 'react';
import { usePortfolio } from '../context/PortfolioContext';
import { useTheme } from '../context/ThemeContext';
import { Download, FileText, Code, Image, X, CheckCircle } from 'lucide-react';

interface ExportModalProps {
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ onClose }) => {
  const { data } = usePortfolio();
  const { theme } = useTheme();
  const [isExporting, setIsExporting] = useState(false);
  const [exportType, setExportType] = useState<'pdf' | 'json' | 'html'>('pdf');
  const [exportSuccess, setExportSuccess] = useState(false);

  const exportOptions = [
    {
      type: 'pdf' as const,
      icon: FileText,
      title: 'PDF Document',
      description: 'Export as a professional PDF resume',
      color: 'from-red-500 to-pink-500'
    },
    {
      type: 'json' as const,
      icon: Code,
      title: 'JSON Data',
      description: 'Export portfolio data as JSON',
      color: 'from-blue-500 to-indigo-500'
    },
    {
      type: 'html' as const,
      icon: Code,
      title: 'HTML Website',
      description: 'Export as standalone HTML file',
      color: 'from-green-500 to-teal-500'
    }
  ];

  const handleExport = async () => {
    setIsExporting(true);
    setExportSuccess(false);
    
    try {
      await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate processing time
      
      switch (exportType) {
        case 'pdf':
          await exportAsPDF();
          break;
        case 'json':
          await exportAsJSON();
          break;
        case 'html':
          await exportAsHTML();
          break;
      }
      
      setExportSuccess(true);
      setTimeout(() => {
        setExportSuccess(false);
        onClose();
      }, 2000);
    } catch (error) {
      console.error('Export failed:', error);
    } finally {
      setIsExporting(false);
    }
  };

  const exportAsPDF = async () => {
    // Create a more comprehensive PDF-like content
    const pdfContent = generatePDFContent();
    
    // Create blob with proper PDF-like formatting
    const blob = new Blob([pdfContent], { 
      type: 'application/pdf' 
    });
    
    downloadFile(blob, `${data.personalInfo.name || 'portfolio'}_resume.pdf`);
  };

  const exportAsJSON = async () => {
    const jsonContent = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonContent], { type: 'application/json' });
    downloadFile(blob, `${data.personalInfo.name || 'portfolio'}_data.json`);
  };

  const exportAsHTML = async () => {
    const htmlContent = generateHTMLContent();
    const blob = new Blob([htmlContent], { type: 'text/html' });
    downloadFile(blob, `${data.personalInfo.name || 'portfolio'}_website.html`);
  };

  const downloadFile = (blob: Blob, filename: string) => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const generatePDFContent = () => {
    const { personalInfo, about, workExperience, education, skills, projects, certifications, achievements, publications, summary } = data;
    
    return `
PORTFOLIO RESUME
================

${personalInfo.name || 'Your Name'}
${personalInfo.role || 'Your Professional Role'}

CONTACT INFORMATION
-------------------
Email: ${personalInfo.email || 'Not provided'}
Phone: ${personalInfo.phone || 'Not provided'}
LinkedIn: ${personalInfo.linkedin || 'Not provided'}
GitHub: ${personalInfo.github || 'Not provided'}

${summary ? `
PROFESSIONAL SUMMARY
--------------------
${summary}
` : ''}

${about ? `
ABOUT ME
--------
${about}
` : ''}

${workExperience.length > 0 ? `
WORK EXPERIENCE
---------------
${workExperience.map(work => `
${work.position} at ${work.company}
${work.duration}
${work.description}
`).join('\n')}
` : ''}

${education.length > 0 ? `
EDUCATION
---------
${education.map(edu => `
${edu.degree}
${edu.institution} - ${edu.year}
${edu.description}
`).join('\n')}
` : ''}

${skills.length > 0 ? `
SKILLS
------
${skills.map(skill => `${skill.name}: ${skill.level}% (${skill.category})`).join('\n')}
` : ''}

${projects.length > 0 ? `
FEATURED PROJECTS
-----------------
${projects.map(project => `
${project.title}
${project.description}
Technologies: ${project.technologies.join(', ')}
${project.link ? `Link: ${project.link}` : ''}
`).join('\n')}
` : ''}

${certifications.length > 0 ? `
CERTIFICATIONS
--------------
${certifications.map(cert => `
${cert.name}
Issued by: ${cert.issuer} - ${cert.date}
${cert.link ? `Verification: ${cert.link}` : ''}
`).join('\n')}
` : ''}

${achievements.length > 0 ? `
ACHIEVEMENTS
------------
${achievements.map(achievement => `
${achievement.title} - ${achievement.date}
${achievement.description}
`).join('\n')}
` : ''}

${publications.length > 0 ? `
PUBLICATIONS
------------
${publications.map(pub => `
${pub.title}
${pub.journal} - ${pub.date}
${pub.link ? `Link: ${pub.link}` : ''}
`).join('\n')}
` : ''}

---
Generated with SIVAPALLA's Prompt To Portfolio
Portfolio Generator Application
`;
  };

  const generateHTMLContent = () => {
    const { personalInfo, about, workExperience, education, skills, projects, certifications, achievements, publications, summary } = data;
    
    const themeStyles = {
      dark: {
        bg: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        cardBg: 'rgba(255, 255, 255, 0.1)',
        textColor: '#ffffff',
        mutedColor: 'rgba(255, 255, 255, 0.7)'
      },
      light: {
        bg: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
        cardBg: 'rgba(255, 255, 255, 0.9)',
        textColor: '#333333',
        mutedColor: '#666666'
      },
      neon: {
        bg: 'linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%)',
        cardBg: 'rgba(0, 255, 136, 0.1)',
        textColor: '#00ff88',
        mutedColor: 'rgba(0, 255, 136, 0.7)'
      }
    };

    const currentTheme = themeStyles[theme];

    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${personalInfo.name || 'Portfolio'} - Professional Portfolio</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: ${currentTheme.bg};
            color: ${currentTheme.textColor};
            line-height: 1.6;
            min-height: 100vh;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 20px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 60px;
            padding: 40px;
            background: ${currentTheme.cardBg};
            backdrop-filter: blur(20px);
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        }
        
        .profile-img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 20px;
            border: 4px solid rgba(16, 185, 129, 0.5);
        }
        
        h1 {
            font-size: 3rem;
            margin-bottom: 10px;
            background: linear-gradient(45deg, #10b981, #06d6a0);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .role {
            font-size: 1.5rem;
            color: ${currentTheme.mutedColor};
            margin-bottom: 30px;
        }
        
        .contact {
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
        }
        
        .contact a {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 20px;
            background: ${currentTheme.cardBg};
            color: ${currentTheme.textColor};
            text-decoration: none;
            border-radius: 12px;
            transition: transform 0.3s ease;
            border: 1px solid rgba(16, 185, 129, 0.3);
        }
        
        .contact a:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(16, 185, 129, 0.2);
        }
        
        .section {
            margin: 60px 0;
            padding: 40px;
            background: ${currentTheme.cardBg};
            backdrop-filter: blur(20px);
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        }
        
        .section h2 {
            font-size: 2.5rem;
            margin-bottom: 30px;
            background: linear-gradient(45deg, #10b981, #06d6a0);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            border-bottom: 2px solid rgba(16, 185, 129, 0.3);
            padding-bottom: 15px;
        }
        
        .skills-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }
        
        .skill {
            margin-bottom: 20px;
        }
        
        .skill-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
        }
        
        .skill-bar {
            background: rgba(255, 255, 255, 0.1);
            height: 10px;
            border-radius: 5px;
            overflow: hidden;
        }
        
        .skill-progress {
            background: linear-gradient(90deg, #10b981, #06d6a0);
            height: 100%;
            border-radius: 5px;
            transition: width 0.3s ease;
        }
        
        .projects-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 30px;
        }
        
        .project-card {
            background: ${currentTheme.cardBg};
            border-radius: 15px;
            padding: 25px;
            border: 1px solid rgba(16, 185, 129, 0.2);
            transition: transform 0.3s ease;
        }
        
        .project-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(16, 185, 129, 0.2);
        }
        
        .project-img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        
        .tech-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin: 15px 0;
        }
        
        .tech-tag {
            background: linear-gradient(45deg, #10b981, #06d6a0);
            color: white;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
        }
        
        .work-item, .edu-item {
            border-left: 4px solid #10b981;
            padding-left: 25px;
            margin-bottom: 30px;
        }
        
        .footer {
            text-align: center;
            margin-top: 80px;
            padding: 40px;
            background: ${currentTheme.cardBg};
            backdrop-filter: blur(20px);
            border-radius: 20px;
            color: ${currentTheme.mutedColor};
        }
        
        @media (max-width: 768px) {
            .container { padding: 20px 10px; }
            h1 { font-size: 2rem; }
            .section { padding: 20px; }
            .contact { flex-direction: column; align-items: center; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            ${personalInfo.profilePhoto ? `<img src="${personalInfo.profilePhoto}" alt="Profile" class="profile-img">` : ''}
            <h1>${personalInfo.name || 'Your Name'}</h1>
            <div class="role">${personalInfo.role || 'Your Professional Role'}</div>
            <div class="contact">
                ${personalInfo.email ? `<a href="mailto:${personalInfo.email}">📧 ${personalInfo.email}</a>` : ''}
                ${personalInfo.phone ? `<a href="tel:${personalInfo.phone}">📞 ${personalInfo.phone}</a>` : ''}
                ${personalInfo.linkedin ? `<a href="${personalInfo.linkedin}" target="_blank">💼 LinkedIn</a>` : ''}
                ${personalInfo.github ? `<a href="${personalInfo.github}" target="_blank">🔗 GitHub</a>` : ''}
            </div>
        </div>
        
        ${summary ? `
        <div class="section">
            <h2>Professional Summary</h2>
            <p>${summary}</p>
        </div>` : ''}
        
        ${about ? `
        <div class="section">
            <h2>About Me</h2>
            <p>${about}</p>
        </div>` : ''}
        
        ${workExperience.length > 0 ? `
        <div class="section">
            <h2>Work Experience</h2>
            ${workExperience.map(work => `
            <div class="work-item">
                <h3>${work.position}</h3>
                <p><strong>${work.company}</strong> • ${work.duration}</p>
                <p>${work.description}</p>
            </div>`).join('')}
        </div>` : ''}
        
        ${skills.length > 0 ? `
        <div class="section">
            <h2>Skills</h2>
            <div class="skills-grid">
                ${skills.map(skill => `
                <div class="skill">
                    <div class="skill-header">
                        <span><strong>${skill.name}</strong></span>
                        <span>${skill.level}%</span>
                    </div>
                    <div class="skill-bar">
                        <div class="skill-progress" style="width: ${skill.level}%"></div>
                    </div>
                </div>`).join('')}
            </div>
        </div>` : ''}
        
        ${projects.length > 0 ? `
        <div class="section">
            <h2>Featured Projects</h2>
            <div class="projects-grid">
                ${projects.map(project => `
                <div class="project-card">
                    ${project.image ? `<img src="${project.image}" alt="${project.title}" class="project-img">` : ''}
                    <h3>${project.title}</h3>
                    <p>${project.description}</p>
                    <div class="tech-tags">
                        ${project.technologies.map(tech => `<span class="tech-tag">${tech}</span>`).join('')}
                    </div>
                    ${project.link ? `<a href="${project.link}" target="_blank">🔗 View Project</a>` : ''}
                </div>`).join('')}
            </div>
        </div>` : ''}
        
        ${education.length > 0 ? `
        <div class="section">
            <h2>Education</h2>
            ${education.map(edu => `
            <div class="edu-item">
                <h3>${edu.degree}</h3>
                <p><strong>${edu.institution}</strong> • ${edu.year}</p>
                ${edu.description ? `<p>${edu.description}</p>` : ''}
            </div>`).join('')}
        </div>` : ''}
        
        ${certifications.length > 0 ? `
        <div class="section">
            <h2>Certifications</h2>
            ${certifications.map(cert => `
            <div class="work-item">
                <h3>${cert.name}</h3>
                <p><strong>${cert.issuer}</strong> • ${cert.date}</p>
                ${cert.link ? `<a href="${cert.link}" target="_blank">🔗 Verify Certificate</a>` : ''}
            </div>`).join('')}
        </div>` : ''}
        
        ${achievements.length > 0 ? `
        <div class="section">
            <h2>Achievements</h2>
            ${achievements.map(achievement => `
            <div class="work-item">
                <h3>${achievement.title}</h3>
                <p><strong>${achievement.date}</strong></p>
                <p>${achievement.description}</p>
            </div>`).join('')}
        </div>` : ''}
        
        ${publications.length > 0 ? `
        <div class="section">
            <h2>Publications</h2>
            ${publications.map(pub => `
            <div class="work-item">
                <h3>${pub.title}</h3>
                <p><strong>${pub.journal}</strong> • ${pub.date}</p>
                ${pub.link ? `<a href="${pub.link}" target="_blank">🔗 Read Publication</a>` : ''}
            </div>`).join('')}
        </div>` : ''}
        
        <div class="footer">
            <p>✨ Generated with SIVAPALLA's Prompt To Portfolio</p>
            <p>Professional Portfolio Generator • ${new Date().getFullYear()}</p>
        </div>
    </div>
</body>
</html>`;
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-8 max-w-md w-full">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-2xl font-bold text-white">Export Portfolio</h3>
          <button
            onClick={onClose}
            className="p-2 text-white/70 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {exportSuccess ? (
          <div className="text-center py-8">
            <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-400" />
            <h4 className="text-xl font-semibold text-white mb-2">Export Successful!</h4>
            <p className="text-white/70">Your portfolio has been downloaded successfully.</p>
          </div>
        ) : (
          <>
            <div className="space-y-4 mb-6">
              {exportOptions.map((option) => {
                const Icon = option.icon;
                return (
                  <button
                    key={option.type}
                    onClick={() => setExportType(option.type)}
                    className={`w-full p-4 rounded-xl border-2 transition-all duration-300 ${
                      exportType === option.type
                        ? 'border-white/40 bg-white/10 transform scale-105'
                        : 'border-white/20 hover:border-white/30 hover:bg-white/5'
                    }`}
                  >
                    <div className="flex items-center space-x-4">
                      <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${option.color} flex items-center justify-center`}>
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <div className="text-left">
                        <h4 className="text-white font-semibold">{option.title}</h4>
                        <p className="text-white/70 text-sm">{option.description}</p>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            <button
              onClick={handleExport}
              disabled={isExporting}
              className="w-full flex items-center justify-center space-x-2 px-6 py-3 bg-gradient-to-r from-green-500 to-teal-500 text-white rounded-xl hover:from-green-600 hover:to-teal-600 transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
            >
              {isExporting ? (
                <>
                  <div className="spinner"></div>
                  <span>Exporting...</span>
                </>
              ) : (
                <>
                  <Download className="w-5 h-5" />
                  <span>Export Portfolio</span>
                </>
              )}
            </button>
          </>
        )}
      </div>
    </div>
  );
};