import React from 'react';
import { usePortfolio } from '../../context/PortfolioContext';
import { FolderOpen, Plus, Trash2, ExternalLink, Tag } from 'lucide-react';

export const ProjectsForm: React.FC = () => {
  const { data, updateData } = usePortfolio();

  const addProject = () => {
    const newProject = {
      id: Date.now().toString(),
      title: '',
      description: '',
      technologies: [],
      link: '',
      image: '',
    };
    updateData('projects', [...data.projects, newProject]);
  };

  const removeProject = (id: string) => {
    updateData('projects', data.projects.filter(project => project.id !== id));
  };

  const updateProject = (id: string, field: string, value: any) => {
    updateData('projects', data.projects.map(project =>
      project.id === id ? { ...project, [field]: value } : project
    ));
  };

  const addTechnology = (projectId: string, tech: string) => {
    if (tech.trim()) {
      const project = data.projects.find(p => p.id === projectId);
      if (project && !project.technologies.includes(tech.trim())) {
        updateProject(projectId, 'technologies', [...project.technologies, tech.trim()]);
      }
    }
  };

  const removeTechnology = (projectId: string, tech: string) => {
    const project = data.projects.find(p => p.id === projectId);
    if (project) {
      updateProject(projectId, 'technologies', project.technologies.filter(t => t !== tech));
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">Featured Projects</h2>
          <p className="text-white/70">Showcase your best work and achievements</p>
        </div>
        <button
          onClick={addProject}
          className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-indigo-500 to-purple-500 text-white rounded-lg hover:from-indigo-600 hover:to-purple-600 transition-all duration-300 transform hover:scale-105"
        >
          <Plus className="w-4 h-4" />
          <span>Add Project</span>
        </button>
      </div>

      <div className="space-y-6">
        {data.projects.map((project) => (
          <div key={project.id} className="bg-white/5 backdrop-blur-xl rounded-xl p-6 border border-white/10">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-2">
                <FolderOpen className="w-5 h-5 text-indigo-400" />
                <span className="text-white font-medium">Project</span>
              </div>
              <button
                onClick={() => removeProject(project.id)}
                className="p-2 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition-all duration-300"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-white/70 text-sm mb-1">Project Title</label>
                  <input
                    type="text"
                    value={project.title}
                    onChange={(e) => updateProject(project.id, 'title', e.target.value)}
                    className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-300"
                    placeholder="Awesome Project Name"
                  />
                </div>

                <div>
                  <label className="block text-white/70 text-sm mb-1">Description</label>
                  <textarea
                    value={project.description}
                    onChange={(e) => updateProject(project.id, 'description', e.target.value)}
                    rows={4}
                    className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-300 resize-none"
                    placeholder="Describe what this project does, the problem it solves, and your role in it..."
                  />
                </div>

                <div>
                  <label className="block text-white/70 text-sm mb-1">Project Link</label>
                  <div className="relative">
                    <ExternalLink className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-white/50" />
                    <input
                      type="url"
                      value={project.link}
                      onChange={(e) => updateProject(project.id, 'link', e.target.value)}
                      className="w-full pl-10 pr-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-300"
                      placeholder="https://github.com/username/project"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-white/70 text-sm mb-1">Project Image URL</label>
                  <input
                    type="url"
                    value={project.image}
                    onChange={(e) => updateProject(project.id, 'image', e.target.value)}
                    className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-300"
                    placeholder="https://example.com/project-screenshot.jpg"
                  />
                  {project.image && (
                    <div className="mt-2">
                      <img
                        src={project.image}
                        alt="Project preview"
                        className="w-full h-32 object-cover rounded-lg"
                        onError={(e) => {
                          (e.target as HTMLImageElement).style.display = 'none';
                        }}
                      />
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-white/70 text-sm mb-2">Technologies Used</label>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {project.technologies.map((tech) => (
                      <span
                        key={tech}
                        className="inline-flex items-center px-3 py-1 bg-gradient-to-r from-indigo-500 to-purple-500 text-white text-sm rounded-full"
                      >
                        <Tag className="w-3 h-3 mr-1" />
                        {tech}
                        <button
                          onClick={() => removeTechnology(project.id, tech)}
                          className="ml-2 text-white/70 hover:text-white"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>
                  <input
                    type="text"
                    placeholder="Add technology (press Enter)"
                    className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-300"
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        addTechnology(project.id, (e.target as HTMLInputElement).value);
                        (e.target as HTMLInputElement).value = '';
                      }
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        ))}

        {data.projects.length === 0 && (
          <div className="text-center py-12 text-white/50">
            <FolderOpen className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No projects added yet. Click "Add Project" to showcase your work.</p>
          </div>
        )}
      </div>
    </div>
  );
};