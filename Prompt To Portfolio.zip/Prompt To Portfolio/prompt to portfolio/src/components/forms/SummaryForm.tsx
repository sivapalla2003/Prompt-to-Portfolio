import React from 'react';
import { usePortfolio } from '../../context/PortfolioContext';
import { Sparkles, RefreshCw } from 'lucide-react';

export const SummaryForm: React.FC = () => {
  const { data, updateData, generateSummary } = usePortfolio();

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-white mb-2">Professional Summary</h2>
        <p className="text-white/70">A concise overview of your professional profile</p>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <label className="block text-white font-medium flex items-center space-x-2">
            <Sparkles className="w-5 h-5" />
            <span>Summary</span>
          </label>
          <button
            onClick={generateSummary}
            className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg hover:from-purple-600 hover:to-pink-600 transition-all duration-300 transform hover:scale-105"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Generate AI Summary</span>
          </button>
        </div>
        
        <textarea
          value={data.summary}
          onChange={(e) => updateData('summary', e.target.value)}
          rows={6}
          className="w-full px-4 py-3 bg-white/10 backdrop-blur-xl border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-300 resize-none"
          placeholder="Write a professional summary that highlights your key strengths, experience, and career objectives. This will be displayed prominently on your portfolio..."
        />
        
        <div className="bg-white/5 backdrop-blur-xl rounded-lg p-4 border border-white/10">
          <h4 className="text-white font-medium mb-2">Tips for a great summary:</h4>
          <ul className="text-white/70 text-sm space-y-1">
            <li>• Keep it concise (2-3 sentences)</li>
            <li>• Highlight your most relevant skills and experience</li>
            <li>• Include your career objectives or passion</li>
            <li>• Use the "Generate AI Summary" button for inspiration</li>
          </ul>
        </div>
      </div>
    </div>
  );
};