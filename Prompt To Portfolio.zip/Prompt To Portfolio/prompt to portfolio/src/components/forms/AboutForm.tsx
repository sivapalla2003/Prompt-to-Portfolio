import React from 'react';
import { usePortfolio } from '../../context/PortfolioContext';
import { FileText } from 'lucide-react';

export const AboutForm: React.FC = () => {
  const { data, updateData } = usePortfolio();

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-white mb-2">About You</h2>
        <p className="text-white/70">Tell us about yourself and your professional journey</p>
      </div>

      <div className="space-y-4">
        <label className="block text-white font-medium flex items-center space-x-2">
          <FileText className="w-5 h-5" />
          <span>Your Story</span>
        </label>
        <textarea
          value={data.about}
          onChange={(e) => updateData('about', e.target.value)}
          rows={8}
          className="w-full px-4 py-3 bg-white/10 backdrop-blur-xl border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-300 resize-none"
          placeholder="Write about your professional background, interests, and what drives you. This is your chance to make a great first impression..."
        />
        <p className="text-white/50 text-sm">
          Tip: Include your passion, experience, and what makes you unique as a professional.
        </p>
      </div>
    </div>
  );
};