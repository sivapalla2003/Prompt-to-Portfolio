import React from 'react';
import { usePortfolio } from '../../context/PortfolioContext';
import { Trophy, Plus, Trash2 } from 'lucide-react';

export const AchievementsForm: React.FC = () => {
  const { data, updateData } = usePortfolio();

  const addAchievement = () => {
    const newAchievement = {
      id: Date.now().toString(),
      title: '',
      description: '',
      date: '',
    };
    updateData('achievements', [...data.achievements, newAchievement]);
  };

  const removeAchievement = (id: string) => {
    updateData('achievements', data.achievements.filter(achievement => achievement.id !== id));
  };

  const updateAchievement = (id: string, field: string, value: string) => {
    updateData('achievements', data.achievements.map(achievement =>
      achievement.id === id ? { ...achievement, [field]: value } : achievement
    ));
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">Achievements</h2>
          <p className="text-white/70">Highlight your notable accomplishments and awards</p>
        </div>
        <button
          onClick={addAchievement}
          className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-lg hover:from-pink-600 hover:to-rose-600 transition-all duration-300 transform hover:scale-105"
        >
          <Plus className="w-4 h-4" />
          <span>Add Achievement</span>
        </button>
      </div>

      <div className="space-y-6">
        {data.achievements.map((achievement) => (
          <div key={achievement.id} className="bg-white/5 backdrop-blur-xl rounded-xl p-6 border border-white/10">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <Trophy className="w-5 h-5 text-pink-400" />
                <span className="text-white font-medium">Achievement</span>
              </div>
              <button
                onClick={() => removeAchievement(achievement.id)}
                className="p-2 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition-all duration-300"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-white/70 text-sm mb-1">Achievement Title</label>
                <input
                  type="text"
                  value={achievement.title}
                  onChange={(e) => updateAchievement(achievement.id, 'title', e.target.value)}
                  className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent transition-all duration-300"
                  placeholder="Employee of the Year 2023"
                />
              </div>

              <div>
                <label className="block text-white/70 text-sm mb-1">Date</label>
                <input
                  type="text"
                  value={achievement.date}
                  onChange={(e) => updateAchievement(achievement.id, 'date', e.target.value)}
                  className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent transition-all duration-300"
                  placeholder="December 2023"
                />
              </div>

              <div>
                <label className="block text-white/70 text-sm mb-1">Description</label>
                <textarea
                  value={achievement.description}
                  onChange={(e) => updateAchievement(achievement.id, 'description', e.target.value)}
                  rows={3}
                  className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent transition-all duration-300 resize-none"
                  placeholder="Describe the achievement and its significance..."
                />
              </div>
            </div>
          </div>
        ))}

        {data.achievements.length === 0 && (
          <div className="text-center py-12 text-white/50">
            <Trophy className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No achievements added yet. Click "Add Achievement" to get started.</p>
          </div>
        )}
      </div>
    </div>
  );
};