import React from 'react';
import { usePortfolio } from '../../context/PortfolioContext';
import { BookOpen, Plus, Trash2, ExternalLink } from 'lucide-react';

export const PublicationsForm: React.FC = () => {
  const { data, updateData } = usePortfolio();

  const addPublication = () => {
    const newPublication = {
      id: Date.now().toString(),
      title: '',
      journal: '',
      date: '',
      link: '',
    };
    updateData('publications', [...data.publications, newPublication]);
  };

  const removePublication = (id: string) => {
    updateData('publications', data.publications.filter(pub => pub.id !== id));
  };

  const updatePublication = (id: string, field: string, value: string) => {
    updateData('publications', data.publications.map(pub =>
      pub.id === id ? { ...pub, [field]: value } : pub
    ));
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">Publications</h2>
          <p className="text-white/70">Add your research papers, articles, and publications</p>
        </div>
        <button
          onClick={addPublication}
          className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-teal-500 to-cyan-500 text-white rounded-lg hover:from-teal-600 hover:to-cyan-600 transition-all duration-300 transform hover:scale-105"
        >
          <Plus className="w-4 h-4" />
          <span>Add Publication</span>
        </button>
      </div>

      <div className="space-y-6">
        {data.publications.map((publication) => (
          <div key={publication.id} className="bg-white/5 backdrop-blur-xl rounded-xl p-6 border border-white/10">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <BookOpen className="w-5 h-5 text-teal-400" />
                <span className="text-white font-medium">Publication</span>
              </div>
              <button
                onClick={() => removePublication(publication.id)}
                className="p-2 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition-all duration-300"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-white/70 text-sm mb-1">Publication Title</label>
                <input
                  type="text"
                  value={publication.title}
                  onChange={(e) => updatePublication(publication.id, 'title', e.target.value)}
                  className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all duration-300"
                  placeholder="Machine Learning Applications in Healthcare"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-white/70 text-sm mb-1">Journal/Conference</label>
                  <input
                    type="text"
                    value={publication.journal}
                    onChange={(e) => updatePublication(publication.id, 'journal', e.target.value)}
                    className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all duration-300"
                    placeholder="IEEE Transactions on AI"
                  />
                </div>
                <div>
                  <label className="block text-white/70 text-sm mb-1">Publication Date</label>
                  <input
                    type="text"
                    value={publication.date}
                    onChange={(e) => updatePublication(publication.id, 'date', e.target.value)}
                    className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all duration-300"
                    placeholder="January 2023"
                  />
                </div>
              </div>

              <div>
                <label className="block text-white/70 text-sm mb-1">Publication Link</label>
                <div className="relative">
                  <ExternalLink className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-white/50" />
                  <input
                    type="url"
                    value={publication.link}
                    onChange={(e) => updatePublication(publication.id, 'link', e.target.value)}
                    className="w-full pl-10 pr-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all duration-300"
                    placeholder="https://doi.org/10.1234/example"
                  />
                </div>
              </div>
            </div>
          </div>
        ))}

        {data.publications.length === 0 && (
          <div className="text-center py-12 text-white/50">
            <BookOpen className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No publications added yet. Click "Add Publication" to get started.</p>
          </div>
        )}
      </div>
    </div>
  );
};