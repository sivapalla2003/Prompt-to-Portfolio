import React from 'react';
import { usePortfolio } from '../../context/PortfolioContext';
import { User, Mail, Phone, Linkedin, Github, Plus, Camera } from 'lucide-react';

export const PersonalInfoForm: React.FC = () => {
  const { data, updateData } = usePortfolio();
  const { personalInfo } = data;

  const handleChange = (field: string, value: string) => {
    updateData('personalInfo', { ...personalInfo, [field]: value });
  };

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        handleChange('profilePhoto', e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-white mb-2">Personal Information</h2>
        <p className="text-white/70">Let's start with your basic details</p>
      </div>

      {/* Profile Photo */}
      <div className="flex justify-center">
        <div className="relative group">
          <div className="w-32 h-32 rounded-full bg-gradient-to-r from-green-400 to-cyan-400 p-1">
            <div className="w-full h-full rounded-full bg-white/10 backdrop-blur-xl overflow-hidden flex items-center justify-center">
              {personalInfo.profilePhoto ? (
                <img
                  src={personalInfo.profilePhoto}
                  alt="Profile"
                  className="w-full h-full object-cover rounded-full"
                />
              ) : (
                <Camera className="w-12 h-12 text-white/50" />
              )}
            </div>
          </div>
          <label
            htmlFor="photo-upload"
            className="absolute -bottom-2 -right-2 w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center cursor-pointer hover:scale-110 transition-transform duration-300 shadow-lg"
          >
            <Plus className="w-5 h-5 text-white" />
          </label>
          <input
            id="photo-upload"
            type="file"
            accept="image/*"
            onChange={handlePhotoUpload}
            className="hidden"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Name */}
        <div className="space-y-2">
          <label className="block text-white font-medium">Full Name</label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/50" />
            <input
              type="text"
              value={personalInfo.name}
              onChange={(e) => handleChange('name', e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-white/10 backdrop-blur-xl border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-300"
              placeholder="Enter your full name"
            />
          </div>
        </div>

        {/* Role */}
        <div className="space-y-2">
          <label className="block text-white font-medium">Professional Role</label>
          <input
            type="text"
            value={personalInfo.role}
            onChange={(e) => handleChange('role', e.target.value)}
            className="w-full px-4 py-3 bg-white/10 backdrop-blur-xl border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-300"
            placeholder="e.g., Software Engineer, Designer"
          />
        </div>

        {/* Email */}
        <div className="space-y-2">
          <label className="block text-white font-medium">Email</label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/50" />
            <input
              type="email"
              value={personalInfo.email}
              onChange={(e) => handleChange('email', e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-white/10 backdrop-blur-xl border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-300"
              placeholder="your.email@example.com"
            />
          </div>
        </div>

        {/* Phone */}
        <div className="space-y-2">
          <label className="block text-white font-medium">Phone</label>
          <div className="relative">
            <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/50" />
            <input
              type="tel"
              value={personalInfo.phone}
              onChange={(e) => handleChange('phone', e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-white/10 backdrop-blur-xl border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-300"
              placeholder="+1 (555) 123-4567"
            />
          </div>
        </div>

        {/* LinkedIn */}
        <div className="space-y-2">
          <label className="block text-white font-medium">LinkedIn</label>
          <div className="relative">
            <Linkedin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/50" />
            <input
              type="url"
              value={personalInfo.linkedin}
              onChange={(e) => handleChange('linkedin', e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-white/10 backdrop-blur-xl border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-300"
              placeholder="https://linkedin.com/in/yourprofile"
            />
          </div>
        </div>

        {/* GitHub */}
        <div className="space-y-2">
          <label className="block text-white font-medium">GitHub</label>
          <div className="relative">
            <Github className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/50" />
            <input
              type="url"
              value={personalInfo.github}
              onChange={(e) => handleChange('github', e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-white/10 backdrop-blur-xl border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-300"
              placeholder="https://github.com/yourusername"
            />
          </div>
        </div>
      </div>
    </div>
  );
};