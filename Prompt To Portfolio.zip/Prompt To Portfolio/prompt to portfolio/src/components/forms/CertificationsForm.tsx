import React from 'react';
import { usePortfolio } from '../../context/PortfolioContext';
import { Award, Plus, Trash2, ExternalLink } from 'lucide-react';

export const CertificationsForm: React.FC = () => {
  const { data, updateData } = usePortfolio();

  const addCertification = () => {
    const newCertification = {
      id: Date.now().toString(),
      name: '',
      issuer: '',
      date: '',
      link: '',
    };
    updateData('certifications', [...data.certifications, newCertification]);
  };

  const removeCertification = (id: string) => {
    updateData('certifications', data.certifications.filter(cert => cert.id !== id));
  };

  const updateCertification = (id: string, field: string, value: string) => {
    updateData('certifications', data.certifications.map(cert =>
      cert.id === id ? { ...cert, [field]: value } : cert
    ));
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">Certifications</h2>
          <p className="text-white/70">Add your professional certifications and achievements</p>
        </div>
        <button
          onClick={addCertification}
          className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-yellow-500 to-orange-500 text-white rounded-lg hover:from-yellow-600 hover:to-orange-600 transition-all duration-300 transform hover:scale-105"
        >
          <Plus className="w-4 h-4" />
          <span>Add Certification</span>
        </button>
      </div>

      <div className="space-y-6">
        {data.certifications.map((cert) => (
          <div key={cert.id} className="bg-white/5 backdrop-blur-xl rounded-xl p-6 border border-white/10">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <Award className="w-5 h-5 text-yellow-400" />
                <span className="text-white font-medium">Certification</span>
              </div>
              <button
                onClick={() => removeCertification(cert.id)}
                className="p-2 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition-all duration-300"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-white/70 text-sm mb-1">Certification Name</label>
                <input
                  type="text"
                  value={cert.name}
                  onChange={(e) => updateCertification(cert.id, 'name', e.target.value)}
                  className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all duration-300"
                  placeholder="AWS Certified Solutions Architect"
                />
              </div>
              <div>
                <label className="block text-white/70 text-sm mb-1">Issuing Organization</label>
                <input
                  type="text"
                  value={cert.issuer}
                  onChange={(e) => updateCertification(cert.id, 'issuer', e.target.value)}
                  className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all duration-300"
                  placeholder="Amazon Web Services"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-white/70 text-sm mb-1">Date Obtained</label>
                <input
                  type="text"
                  value={cert.date}
                  onChange={(e) => updateCertification(cert.id, 'date', e.target.value)}
                  className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all duration-300"
                  placeholder="March 2023"
                />
              </div>
              <div>
                <label className="block text-white/70 text-sm mb-1">Certification Link</label>
                <div className="relative">
                  <ExternalLink className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-white/50" />
                  <input
                    type="url"
                    value={cert.link}
                    onChange={(e) => updateCertification(cert.id, 'link', e.target.value)}
                    className="w-full pl-10 pr-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all duration-300"
                    placeholder="https://verify.certification.com/12345"
                  />
                </div>
              </div>
            </div>
          </div>
        ))}

        {data.certifications.length === 0 && (
          <div className="text-center py-12 text-white/50">
            <Award className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No certifications added yet. Click "Add Certification" to get started.</p>
          </div>
        )}
      </div>
    </div>
  );
};