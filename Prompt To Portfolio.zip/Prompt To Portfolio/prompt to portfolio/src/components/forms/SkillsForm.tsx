import React, { useState } from 'react';
import { usePortfolio } from '../../context/PortfolioContext';
import { Code, Plus, Trash2 } from 'lucide-react';

const skillCategories = [
  'Programming Languages',
  'Frameworks',
  'Databases',
  'Tools & Software',
  'Soft Skills',
  'Other'
];

export const SkillsForm: React.FC = () => {
  const { data, updateData } = usePortfolio();
  const [newSkill, setNewSkill] = useState({ name: '', level: 50, category: 'Programming Languages' });

  const addSkill = () => {
    if (newSkill.name.trim()) {
      const skill = {
        id: Date.now().toString(),
        ...newSkill
      };
      updateData('skills', [...data.skills, skill]);
      setNewSkill({ name: '', level: 50, category: 'Programming Languages' });
    }
  };

  const removeSkill = (id: string) => {
    updateData('skills', data.skills.filter(skill => skill.id !== id));
  };

  const updateSkill = (id: string, field: string, value: any) => {
    updateData('skills', data.skills.map(skill =>
      skill.id === id ? { ...skill, [field]: value } : skill
    ));
  };

  const groupedSkills = data.skills.reduce((acc, skill) => {
    if (!acc[skill.category]) {
      acc[skill.category] = [];
    }
    acc[skill.category].push(skill);
    return acc;
  }, {} as Record<string, typeof data.skills>);

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-white mb-2">Skills</h2>
        <p className="text-white/70">Showcase your technical and soft skills</p>
      </div>

      {/* Add New Skill */}
      <div className="bg-white/5 backdrop-blur-xl rounded-xl p-6 border border-white/10">
        <h3 className="text-white font-semibold mb-4 flex items-center space-x-2">
          <Plus className="w-5 h-5 text-blue-400" />
          <span>Add New Skill</span>
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <input
            type="text"
            value={newSkill.name}
            onChange={(e) => setNewSkill({ ...newSkill, name: e.target.value })}
            className="px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
            placeholder="Skill name (e.g., React, Python)"
          />
          
          <select
            value={newSkill.category}
            onChange={(e) => setNewSkill({ ...newSkill, category: e.target.value })}
            className="px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
          >
            {skillCategories.map(category => (
              <option key={category} value={category} className="bg-gray-800">
                {category}
              </option>
            ))}
          </select>
          
          <div className="flex items-center space-x-2">
            <span className="text-white/70 text-sm">Level:</span>
            <input
              type="range"
              min="0"
              max="100"
              value={newSkill.level}
              onChange={(e) => setNewSkill({ ...newSkill, level: parseInt(e.target.value) })}
              className="flex-1 h-2 bg-white/20 rounded-lg appearance-none cursor-pointer slider"
            />
            <span className="text-white text-sm w-8">{newSkill.level}%</span>
          </div>
        </div>
        
        <button
          onClick={addSkill}
          className="w-full md:w-auto px-6 py-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white rounded-lg hover:from-blue-600 hover:to-indigo-600 transition-all duration-300 transform hover:scale-105"
        >
          Add Skill
        </button>
      </div>

      {/* Skills List */}
      <div className="space-y-6">
        {Object.entries(groupedSkills).map(([category, skills]) => (
          <div key={category} className="bg-white/5 backdrop-blur-xl rounded-xl p-6 border border-white/10">
            <h3 className="text-white font-semibold mb-4 flex items-center space-x-2">
              <Code className="w-5 h-5 text-green-400" />
              <span>{category}</span>
            </h3>
            
            <div className="space-y-3">
              {skills.map((skill) => (
                <div key={skill.id} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <input
                        type="text"
                        value={skill.name}
                        onChange={(e) => updateSkill(skill.id, 'name', e.target.value)}
                        className="bg-transparent text-white font-medium focus:outline-none focus:bg-white/10 px-2 py-1 rounded"
                      />
                      <span className="text-white/70 text-sm">{skill.level}%</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="flex-1 h-2 bg-white/20 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-green-400 to-blue-500 transition-all duration-300"
                          style={{ width: `${skill.level}%` }}
                        />
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        value={skill.level}
                        onChange={(e) => updateSkill(skill.id, 'level', parseInt(e.target.value))}
                        className="w-20 h-2 bg-white/20 rounded-lg appearance-none cursor-pointer slider"
                      />
                    </div>
                  </div>
                  <button
                    onClick={() => removeSkill(skill.id)}
                    className="ml-4 p-2 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition-all duration-300"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        ))}

        {data.skills.length === 0 && (
          <div className="text-center py-12 text-white/50">
            <Code className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No skills added yet. Add your first skill above to get started.</p>
          </div>
        )}
      </div>
    </div>
  );
};