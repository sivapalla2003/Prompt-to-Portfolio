import React from 'react';
import { usePortfolio } from '../../context/PortfolioContext';
import { Briefcase, Plus, Trash2 } from 'lucide-react';

export const WorkExperienceForm: React.FC = () => {
  const { data, updateData } = usePortfolio();

  const addWorkExperience = () => {
    const newWork = {
      id: Date.now().toString(),
      position: '',
      company: '',
      duration: '',
      description: '',
    };
    updateData('workExperience', [...data.workExperience, newWork]);
  };

  const removeWorkExperience = (id: string) => {
    updateData('workExperience', data.workExperience.filter(work => work.id !== id));
  };

  const updateWorkExperience = (id: string, field: string, value: string) => {
    updateData('workExperience', data.workExperience.map(work =>
      work.id === id ? { ...work, [field]: value } : work
    ));
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">Work Experience</h2>
          <p className="text-white/70">Showcase your professional experience</p>
        </div>
        <button
          onClick={addWorkExperience}
          className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg hover:from-purple-600 hover:to-pink-600 transition-all duration-300 transform hover:scale-105"
        >
          <Plus className="w-4 h-4" />
          <span>Add Experience</span>
        </button>
      </div>

      <div className="space-y-6">
        {data.workExperience.map((work) => (
          <div key={work.id} className="bg-white/5 backdrop-blur-xl rounded-xl p-6 border border-white/10">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <Briefcase className="w-5 h-5 text-purple-400" />
                <span className="text-white font-medium">Work Experience</span>
              </div>
              <button
                onClick={() => removeWorkExperience(work.id)}
                className="p-2 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition-all duration-300"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-white/70 text-sm mb-1">Position</label>
                <input
                  type="text"
                  value={work.position}
                  onChange={(e) => updateWorkExperience(work.id, 'position', e.target.value)}
                  className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-300"
                  placeholder="Senior Software Engineer"
                />
              </div>
              <div>
                <label className="block text-white/70 text-sm mb-1">Company</label>
                <input
                  type="text"
                  value={work.company}
                  onChange={(e) => updateWorkExperience(work.id, 'company', e.target.value)}
                  className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-300"
                  placeholder="Company Name"
                />
              </div>
            </div>

            <div className="mb-4">
              <label className="block text-white/70 text-sm mb-1">Duration</label>
              <input
                type="text"
                value={work.duration}
                onChange={(e) => updateWorkExperience(work.id, 'duration', e.target.value)}
                className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-300"
                placeholder="Jan 2022 - Present"
              />
            </div>

            <div>
              <label className="block text-white/70 text-sm mb-1">Description</label>
              <textarea
                value={work.description}
                onChange={(e) => updateWorkExperience(work.id, 'description', e.target.value)}
                rows={4}
                className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-300 resize-none"
                placeholder="Describe your key responsibilities and achievements..."
              />
            </div>
          </div>
        ))}

        {data.workExperience.length === 0 && (
          <div className="text-center py-12 text-white/50">
            <Briefcase className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No work experience entries yet. Click "Add Experience" to get started.</p>
          </div>
        )}
      </div>
    </div>
  );
};