import React, { useState } from 'react';
import { usePortfolio } from '../context/PortfolioContext';
import { Share2, Copy, ExternalLink, X, Check, Globe, Sparkles } from 'lucide-react';

interface ShareModalProps {
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({ onClose }) => {
  const { data } = usePortfolio();
  const [copied, setCopied] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [shareUrl, setShareUrl] = useState('');
  const [error, setError] = useState('');

  const generateShareUrl = async () => {
    setIsGenerating(true);
    setError('');
    
    try {
      // Simulate URL generation with better error handling
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Generate a more realistic portfolio ID
      const portfolioId = `${data.personalInfo.name?.toLowerCase().replace(/\s+/g, '-') || 'portfolio'}-${Math.random().toString(36).substring(2, 8)}`;
      const generatedUrl = `https://sivapalla-portfolio.vercel.app/${portfolioId}`;
      
      setShareUrl(generatedUrl);
    } catch (err) {
      setError('Failed to generate portfolio link. Please try again.');
      console.error('URL generation failed:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = async () => {
    if (shareUrl) {
      try {
        await navigator.clipboard.writeText(shareUrl);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } catch (err) {
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = shareUrl;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }
    }
  };

  const openInNewTab = () => {
    if (shareUrl) {
      window.open(shareUrl, '_blank', 'noopener,noreferrer');
    }
  };

  const shareOnSocialMedia = (platform: string) => {
    if (!shareUrl) return;
    
    const text = `Check out my professional portfolio: ${data.personalInfo.name || 'My Portfolio'}`;
    const encodedUrl = encodeURIComponent(shareUrl);
    const encodedText = encodeURIComponent(text);
    
    const urls = {
      twitter: `https://twitter.com/intent/tweet?text=${encodedText}&url=${encodedUrl}`,
      linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`,
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
      email: `mailto:?subject=${encodeURIComponent('My Professional Portfolio')}&body=${encodedText}%20${encodedUrl}`
    };
    
    if (urls[platform as keyof typeof urls]) {
      window.open(urls[platform as keyof typeof urls], '_blank', 'noopener,noreferrer');
    }
  };

  React.useEffect(() => {
    generateShareUrl();
  }, []);

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-8 max-w-md w-full">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-2xl font-bold text-white flex items-center space-x-2">
            <Share2 className="w-6 h-6" />
            <span>Share Portfolio</span>
          </h3>
          <button
            onClick={onClose}
            className="p-2 text-white/70 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 mx-auto mb-4 bg-red-500/20 rounded-full flex items-center justify-center">
              <X className="w-8 h-8 text-red-400" />
            </div>
            <p className="text-red-400 mb-4">{error}</p>
            <button
              onClick={generateShareUrl}
              className="px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-lg hover:from-blue-600 hover:to-purple-600 transition-all duration-300"
            >
              Try Again
            </button>
          </div>
        ) : isGenerating ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center animate-pulse-custom">
              <Globe className="w-8 h-8 text-white" />
            </div>
            <div className="spinner mx-auto mb-4"></div>
            <p className="text-white/70">Generating your portfolio link...</p>
            <p className="text-white/50 text-sm mt-2">Creating a unique URL for your portfolio</p>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="bg-white/5 backdrop-blur-xl rounded-xl p-4 border border-white/10">
              <h4 className="text-white font-semibold mb-2 flex items-center space-x-2">
                <Sparkles className="w-4 h-4 text-green-400" />
                <span>Your Portfolio URL</span>
              </h4>
              <div className="flex items-center space-x-2 p-3 bg-white/10 rounded-lg">
                <code className="flex-1 text-green-400 text-sm font-mono truncate">
                  {shareUrl}
                </code>
                <button
                  onClick={copyToClipboard}
                  className="p-2 text-white/70 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-300"
                  title="Copy to clipboard"
                >
                  {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
              {copied && (
                <p className="text-green-400 text-sm mt-2 animate-fadeIn">✓ Copied to clipboard!</p>
              )}
            </div>

            <div className="space-y-3">
              <button
                onClick={copyToClipboard}
                className="w-full flex items-center justify-center space-x-2 px-4 py-3 bg-gradient-to-r from-blue-500 to-indigo-500 text-white rounded-lg hover:from-blue-600 hover:to-indigo-600 transition-all duration-300 transform hover:scale-105"
              >
                <Copy className="w-4 h-4" />
                <span>Copy Link</span>
              </button>

              <button
                onClick={openInNewTab}
                className="w-full flex items-center justify-center space-x-2 px-4 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg hover:from-purple-600 hover:to-pink-600 transition-all duration-300 transform hover:scale-105"
              >
                <ExternalLink className="w-4 h-4" />
                <span>Open Portfolio</span>
              </button>
            </div>

            <div className="bg-white/5 backdrop-blur-xl rounded-xl p-4 border border-white/10">
              <h4 className="text-white font-semibold mb-3">Share on Social Media</h4>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => shareOnSocialMedia('twitter')}
                  className="flex items-center justify-center space-x-2 px-3 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors duration-300 text-sm"
                >
                  <span>🐦</span>
                  <span>Twitter</span>
                </button>
                <button
                  onClick={() => shareOnSocialMedia('linkedin')}
                  className="flex items-center justify-center space-x-2 px-3 py-2 bg-blue-700 text-white rounded-lg hover:bg-blue-800 transition-colors duration-300 text-sm"
                >
                  <span>💼</span>
                  <span>LinkedIn</span>
                </button>
                <button
                  onClick={() => shareOnSocialMedia('facebook')}
                  className="flex items-center justify-center space-x-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-300 text-sm"
                >
                  <span>📘</span>
                  <span>Facebook</span>
                </button>
                <button
                  onClick={() => shareOnSocialMedia('email')}
                  className="flex items-center justify-center space-x-2 px-3 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors duration-300 text-sm"
                >
                  <span>📧</span>
                  <span>Email</span>
                </button>
              </div>
            </div>

            <div className="bg-gradient-to-r from-green-500/10 to-teal-500/10 rounded-xl p-4 border border-green-500/20">
              <h4 className="text-green-400 font-semibold mb-2">Portfolio Features</h4>
              <ul className="text-white/70 text-sm space-y-1">
                <li>• Responsive design for all devices</li>
                <li>• Professional layout with modern styling</li>
                <li>• Optimized for sharing and viewing</li>
                <li>• Fast loading and mobile-friendly</li>
              </ul>
            </div>

            <div className="text-center">
              <p className="text-white/50 text-xs">
                Portfolio links are hosted securely and optimized for professional sharing.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};