import React, { useState, useEffect } from 'react';
import { PortfolioBuilder } from './components/PortfolioBuilder';
import { PortfolioPreview } from './components/PortfolioPreview';
import { ThemeProvider } from './context/ThemeContext';
import { PortfolioProvider } from './context/PortfolioContext';
import { Header } from './components/Header';
import { ExportModal } from './components/ExportModal';
import { ShareModal } from './components/ShareModal';

function App() {
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);

  return (
    <ThemeProvider>
      <PortfolioProvider>
        <div className="min-h-screen bg-gradient-to-br from-purple-900 via-indigo-900 to-blue-900 dark:from-gray-900 dark:via-purple-900 dark:to-indigo-900">
          <Header 
            isPreviewMode={isPreviewMode}
            setIsPreviewMode={setIsPreviewMode}
            setShowExportModal={setShowExportModal}
            setShowShareModal={setShowShareModal}
          />
          
          <main className="container mx-auto px-4 py-8">
            {isPreviewMode ? <PortfolioPreview /> : <PortfolioBuilder />}
          </main>

          {showExportModal && (
            <ExportModal onClose={() => setShowExportModal(false)} />
          )}

          {showShareModal && (
            <ShareModal onClose={() => setShowShareModal(false)} />
          )}
        </div>
      </PortfolioProvider>
    </ThemeProvider>
  );
}

export default App;