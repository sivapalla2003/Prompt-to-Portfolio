import React, { createContext, useContext, useState } from 'react';

export interface PortfolioData {
  personalInfo: {
    name: string;
    role: string;
    email: string;
    phone: string;
    linkedin: string;
    github: string;
    profilePhoto: string;
  };
  about: string;
  education: Array<{
    id: string;
    degree: string;
    institution: string;
    year: string;
    description: string;
  }>;
  workExperience: Array<{
    id: string;
    position: string;
    company: string;
    duration: string;
    description: string;
  }>;
  skills: Array<{
    id: string;
    name: string;
    level: number;
    category: string;
  }>;
  projects: Array<{
    id: string;
    title: string;
    description: string;
    technologies: string[];
    link: string;
    image: string;
  }>;
  certifications: Array<{
    id: string;
    name: string;
    issuer: string;
    date: string;
    link: string;
  }>;
  achievements: Array<{
    id: string;
    title: string;
    description: string;
    date: string;
  }>;
  publications: Array<{
    id: string;
    title: string;
    journal: string;
    date: string;
    link: string;
  }>;
  summary: string;
}

interface PortfolioContextType {
  data: PortfolioData;
  updateData: (section: keyof PortfolioData, value: any) => void;
  generateSummary: () => void;
  resetData: () => void;
}

const initialData: PortfolioData = {
  personalInfo: {
    name: '',
    role: '',
    email: '',
    phone: '',
    linkedin: '',
    github: '',
    profilePhoto: '',
  },
  about: '',
  education: [],
  workExperience: [],
  skills: [],
  projects: [],
  certifications: [],
  achievements: [],
  publications: [],
  summary: '',
};

const PortfolioContext = createContext<PortfolioContextType | undefined>(undefined);

export const PortfolioProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [data, setData] = useState<PortfolioData>(initialData);

  const updateData = (section: keyof PortfolioData, value: any) => {
    setData(prev => ({ ...prev, [section]: value }));
  };

  const generateSummary = () => {
    const { personalInfo, skills, workExperience, education } = data;
    let summary = `${personalInfo.role || 'Professional'}`;
    
    if (workExperience.length > 0) {
      summary += ` with ${workExperience.length} years of experience`;
    }
    
    if (skills.length > 0) {
      const topSkills = skills.slice(0, 3).map(skill => skill.name).join(', ');
      summary += ` specializing in ${topSkills}`;
    }
    
    if (education.length > 0) {
      summary += `. Holds ${education[0].degree} from ${education[0].institution}`;
    }
    
    summary += '. Passionate about creating innovative solutions and driving business growth.';
    
    updateData('summary', summary);
  };

  const resetData = () => {
    setData(initialData);
  };

  return (
    <PortfolioContext.Provider value={{ data, updateData, generateSummary, resetData }}>
      {children}
    </PortfolioContext.Provider>
  );
};

export const usePortfolio = () => {
  const context = useContext(PortfolioContext);
  if (!context) {
    throw new Error('usePortfolio must be used within a PortfolioProvider');
  }
  return context;
};